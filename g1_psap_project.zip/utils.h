#ifndef UTILS_H
#define UTILS_H

#include "main.h"

void clearScreen();
void displayMenu();

#endif