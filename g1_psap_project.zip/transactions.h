#ifndef TRANSACTIONS_H
#define TRANSACTIONS_H

#include "main.h"

void addTransaction(char *username);
void viewTransactions(char *username);
void generateReport(char *username);

#endif